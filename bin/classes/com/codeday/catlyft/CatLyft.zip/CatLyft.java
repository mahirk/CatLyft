package com.codeday.catlyft;

import android.os.Bundle;
import android.app.Activity;
import android.app.Application;
import android.view.Menu;

public class CatLyft extends Application {
	static final String TAG = "Catlyft";
	/*@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}*/

}
